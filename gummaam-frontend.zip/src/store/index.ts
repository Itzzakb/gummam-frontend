import { configureStore } from '@reduxjs/toolkit';

export const store = configureStore({
  reducer: {
    app: (state = { initialized: true }) => state,
  },
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
